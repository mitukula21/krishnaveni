package com.Bean;

public class PolicyBean {
	String ques;
	String ans;
	String val;
	public PolicyBean(String ques,String ans,String val)
	{
		this.ques=ques;
		this.ans=ans;
		this.val=val;
	}
	public String getQues() {
		return ques;
	}
	public void setQues(String ques) {
		this.ques = ques;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public String getVal() {
		return val;
	}
	public void setVal(String val) {
		this.val = val;
	}

}
